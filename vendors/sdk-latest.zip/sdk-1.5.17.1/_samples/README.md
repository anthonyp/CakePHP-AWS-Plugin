# Samples for the AWS SDK for PHP

This is a small handful of samples that should be ready-to-run. For more tutorials, screencasts and other
educational materials, check out the [PHP Developer Center](http://aws.amazon.com/php) to learn more.

If a file begins with:

* `html` -- You should run this in a web browser because it outputs HTML.
* `cli` -- You can run this on the command line (via `php <filename>`) OR in a web browser.
